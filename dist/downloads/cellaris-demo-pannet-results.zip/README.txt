Cellaris AI Demo - comparison demo results: PanNETs vs adjacent pancreas (GEO GSE281039)

Data: bulk RNA-seq of 10 pancreatic neuroendocrine tumors and 6 tumor-adjacent pancreas samples
(Niedra et al., PLOS One 2025, doi:10.1371/journal.pone.0325672; data CC BY 4.0).

  cell_fractions.csv                     estimated fraction of each cell type per sample (rows sum to 1)
  comparison/                            two-group comparison, PanNET (test) vs Adjacent pancreas (reference):
    bulk_differential_expression.csv     per gene: mean normalized count, log2 fold change and its standard error,
                                         shrunken log2 fold change, test statistic, p, adjusted p, direction,
                                         whether shrinkage changes the sign of the fold change
    bulk_pathway_enrichment.csv          gene-set enrichment of the genes ranked by the test statistic (Hallmark,
                                         Reactome, WikiPathways, GO BP): enrichment score, normalized enrichment
                                         score, set size, p, adjusted p, top contributing genes
    bulk_progeny_activity.csv            PROGENy pathway activity (test vs reference), p and adjusted p
    bulk_theme_consensus.csv, bulk_best_match_concordance.csv   agreement across gene-set databases
    composition_comparison.csv           estimated fractions per group and test; composition_reference_fit.csv:
                                         how well each sample is described by the healthy reference cell types
  analysis_result.json                   summary shown on the website
  LICENSES.txt                           gene-set licenses and attributions

Tumor samples lie outside the healthy pancreas reference: their estimated fractions describe them as mixtures
of healthy pancreas cell types only. Estimated single-cell profiles of tumor samples are not provided.
For research use only.
