Cellaris AI Demo - results for the human islet cohort (GEO GSE50244)

Bulk RNA-seq of isolated pancreatic islets from 89 organ donors (Fadista et al., PNAS 2014).

Files
  cell_fractions.csv                    estimated fraction of cells of each type per donor (0-1; rows sum to 1)
  donor_metadata.csv                    age (years), sex, BMI (kg/m2) and HbA1c (%) from the GEO series record
  profiles_per_sample.csv               number of single-cell profiles estimated per donor and cell type
  pathway_activity_by_cell_type.csv     mean estimated activity per KEGG pathway and cell type (relative units)
  pathway_activity_per_profile.csv.gz   pathway activity of each of the 8,900 single-cell profiles (relative units)
  profile_annotations.csv               donor, cell type and metabolic map coordinates (UMAP 1/2, no units) per profile
  reaction_metadata.csv                 metabolic reactions scored
  marker_expression_by_cell_type.csv    mean expression of marker genes, log(1 + counts per 10,000)

Activity values are relative scores; compare them within this analysis. Single-cell profiles are
computational estimates derived from bulk data. For research use only.
