Cellaris AI Demo - results for the human islet cohort (GEO GSE50244)

Bulk RNA-seq of isolated pancreatic islets from 89 organ donors (Fadista et al., PNAS 2014).

Files
  cell_fractions.csv                    estimated fraction of cells of each type per donor (0-1; rows sum to 1)
  donor_metadata.csv                    age (years), sex, BMI (kg/m2) and HbA1c (%) from the GEO series record
  profiles_per_sample.csv               number of single-cell profiles estimated per donor and cell type
  pathway_activity_by_cell_type.csv     mean estimated activity per KEGG pathway and cell type (relative units)
  pathway_activity_per_profile.csv.gz   pathway activity of each of the 26,697 single-cell profiles (relative units)
  profile_annotations.csv               donor, cell type and metabolic map coordinates (UMAP 1/2, no units) per profile
  reaction_metadata.csv                 metabolic reactions (KEGG identifiers) and the human KEGG pathways they belong to
  marker_expression_by_cell_type.csv    mean expression of marker genes, log(1 + counts per 10,000)
  literature_support.csv                human pancreas literature for every pathway map reaction: papers that mention
                                        its enzymes (pancreatic cancer papers excluded unless marked incl_cancer),
                                        papers in the cell type with the highest relative activity, expected count and
                                        enrichment, curated enzyme evidence, recent PubMed IDs and candidate hypotheses
  pathway_activity/                     signaling and functional pathway (gene-set) activity:
    geneset_activity_by_cell_type_<collection>.csv   mean activity per cell type (relative units), genes used /
                                         library genes, theme and cross-database consistency label per set
                                         (collections: H = Hallmark, PROGENY, REACTOME, WIKIPATHWAYS, GOBP)
    geneset_activity_by_sample_H.csv.gz, geneset_activity_by_sample_PROGENY.csv.gz
                                         mean activity per donor and cell type with the number of profiles and a
                                         reliability flag (values withheld below 10 profiles). Analyses also produce
                                         these tables for the other collections; they are omitted here for size.
    geneset_coverage.csv                 genes of every library set found among the scoring genes
  LICENSES.txt                          gene-set licenses and attributions

Pathways are the 83 KEGG metabolic pathways present in human cells that were scored.
Activity values are relative scores; compare them within this analysis. Single-cell profiles are
computational estimates derived from bulk data. Paper counts show that enzymes have been studied
in human pancreas; they do not show that a reaction is active. For research use only.
